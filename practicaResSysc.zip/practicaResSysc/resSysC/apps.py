from django.apps import AppConfig


class RessyscConfig(AppConfig):
    name = 'resSysC'
